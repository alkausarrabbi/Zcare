const firebaseConfig = {
  apiKey: "AIzaSyCxr96ntyW5Y2neXQVd4-XZeLl5xWlwGmQ",
  authDomain: "z-care-a068f.firebaseapp.com",
  projectId: "z-care-a068f",
  storageBucket: "z-care-a068f.appspot.com",
  messagingSenderId: "908295865822",
  appId: "1:908295865822:web:2da163be9e319ee85cc94f",
  measurementId: "G-VJQGGZD636"
};

  export default firebaseConfig;