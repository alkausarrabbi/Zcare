import React from 'react';

const Detail = (props) => {
    console.log(props);
    return (
        <div>
            
        </div>
    );
};

export default Detail;