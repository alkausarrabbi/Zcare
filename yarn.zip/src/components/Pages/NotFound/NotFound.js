import React from 'react';

const NotFound = () => {
    return (
        <div>
            <h2>404!</h2>
            <h4>Not Found</h4>
        </div>
    );
};

export default NotFound;