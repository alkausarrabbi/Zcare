import React from 'react';

const Footer = () => {
    return (
        <div className="bg-dark text-light font-monospace m-0 p-5">
            <div>
                <h6> | &#169; 2021, All copyrights reserved by Z Care | </h6>
            </div>
        </div>
    );
};

export default Footer;