import React from 'react';

const ReachUs = () => {
    return (
        <div>
            <h2>This is reach us</h2>
        </div>
    );
};

export default ReachUs;